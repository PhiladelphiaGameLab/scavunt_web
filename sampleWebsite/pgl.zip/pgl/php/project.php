<b><?php echo $_GET['projectTitle']; ?></b><br/>
<p><?php echo $_GET['projectTagline']; ?></p><br/>
<p><?php echo $_GET['projectBody']; ?></p><br/>
<a href= <?php echo $_GET['projectLink']; ?> >blog</a>