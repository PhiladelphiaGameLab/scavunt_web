<b><?php echo $_GET['oneTitle']; ?></b><br/>
<?php echo $_GET['oneBody']; ?><br/>
<b><?php echo $_GET['twoTitle']; ?></b><br/>
<?php echo $_GET['twoBody']; ?><br/>
<b><?php echo $_GET['threeTitle']; ?></b><br/>
<?php echo $_GET['threeBody']; ?>